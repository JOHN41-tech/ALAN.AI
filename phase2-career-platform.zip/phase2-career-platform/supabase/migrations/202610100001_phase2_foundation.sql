-- PHASE 2 INTEGRATION STARTER ONLY — reconcile to Phase 1 profile/user/role tables before applying.
-- Assumes Supabase Auth UUID user ids and auth.uid(). Never apply blindly to an existing schema.
create extension if not exists pgcrypto;

create table if not exists public.phase2_opportunities (
 id uuid primary key default gen_random_uuid(), title text not null, company text not null,
 kind text not null check (kind in ('Internship','Full-time','Part-time')),
 domain text, location text, work_mode text check (work_mode in ('Remote','Hybrid','Onsite')),
 skills text[] not null default '{}', description text not null default '', deadline date,
 source_url text, provenance text not null default 'admin', verification_status text not null default 'unverified',
 published boolean not null default false, created_at timestamptz not null default now()
);
create index if not exists phase2_opportunities_search_idx on public.phase2_opportunities using gin(to_tsvector('english',title||' '||company||' '||coalesce(domain,'')));
create index if not exists phase2_opportunities_deadline_idx on public.phase2_opportunities(deadline) where published;

create table if not exists public.phase2_saved_opportunities (
 user_id uuid not null references auth.users(id) on delete cascade,
 opportunity_id uuid not null references public.phase2_opportunities(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(user_id,opportunity_id)
);
create table if not exists public.phase2_applications (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 opportunity_id uuid not null references public.phase2_opportunities(id) on delete restrict,
 status text not null default 'Interested' check(status in ('Interested','Saved','Applied','Assessment','Interview','Offer','Rejected','Withdrawn')),
 notes text not null default '', created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 unique(user_id,opportunity_id)
);
create index if not exists phase2_applications_user_idx on public.phase2_applications(user_id,updated_at desc);

create table if not exists public.phase2_career_profiles (
 user_id uuid primary key references auth.users(id) on delete cascade,
 answers jsonb not null default '{}'::jsonb, target_domain text, updated_at timestamptz not null default now()
);
create table if not exists public.phase2_roadmaps (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 title text not null, domain text not null, weekly_hours int not null default 5 check(weekly_hours between 1 and 40),
 status text not null default 'active' check(status in ('active','paused','completed')), created_at timestamptz not null default now()
);
create index if not exists phase2_roadmaps_user_idx on public.phase2_roadmaps(user_id,created_at desc);
create table if not exists public.phase2_roadmap_tasks (
 id uuid primary key default gen_random_uuid(), roadmap_id uuid not null references public.phase2_roadmaps(id) on delete cascade,
 title text not null, phase text not null, done boolean not null default false, notes text not null default '', position int not null default 0
);
create index if not exists phase2_roadmap_tasks_order_idx on public.phase2_roadmap_tasks(roadmap_id,position);

create table if not exists public.phase2_resources (
 id uuid primary key default gen_random_uuid(), title text not null, provider text not null,
 domain text not null, level text not null check(level in ('Beginner','Intermediate','Advanced')),
 resource_type text not null, url text not null, skills text[] not null default '{}', checked_at timestamptz,
 published boolean not null default false
);
create table if not exists public.phase2_resource_bookmarks (
 user_id uuid not null references auth.users(id) on delete cascade,
 resource_id uuid not null references public.phase2_resources(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(user_id,resource_id)
);

create table if not exists public.phase2_assessment_attempts (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 assessment_id uuid, score int not null, total int not null check(total > 0), topic text not null,
 -- store selected responses only; correct keys belong in protected server/database functions.
 answers jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);
create index if not exists phase2_attempts_user_idx on public.phase2_assessment_attempts(user_id,created_at desc);
create table if not exists public.phase2_interviews (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 role text not null, status text not null default 'active', turns jsonb not null default '[]'::jsonb,
 created_at timestamptz not null default now(), completed_at timestamptz
);
create table if not exists public.phase2_conversations (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 title text not null, created_at timestamptz not null default now()
);
create table if not exists public.phase2_messages (
 id uuid primary key default gen_random_uuid(), conversation_id uuid not null references public.phase2_conversations(id) on delete cascade,
 role text not null check(role in ('user','assistant')), content text not null check(length(content)<=6000), created_at timestamptz not null default now()
);
create index if not exists phase2_messages_conversation_idx on public.phase2_messages(conversation_id,created_at);

-- RLS on all user-owned records. Opportunity/resource publication is publicly readable only when published.
do $$ declare t text; begin
 foreach t in array array['phase2_saved_opportunities','phase2_applications','phase2_career_profiles','phase2_roadmaps','phase2_resource_bookmarks','phase2_assessment_attempts','phase2_interviews','phase2_conversations'] loop
  execute format('alter table public.%I enable row level security',t);
  execute format('create policy %I on public.%I for select using (user_id = auth.uid())',t||'_read_own',t);
  execute format('create policy %I on public.%I for insert with check (user_id = auth.uid())',t||'_insert_own',t);
  execute format('create policy %I on public.%I for update using (user_id = auth.uid()) with check (user_id = auth.uid())',t||'_update_own',t);
  execute format('create policy %I on public.%I for delete using (user_id = auth.uid())',t||'_delete_own',t);
 end loop;
end $$;
alter table public.phase2_roadmap_tasks enable row level security;
create policy phase2_tasks_read_own on public.phase2_roadmap_tasks for select using (exists(select 1 from public.phase2_roadmaps r where r.id=roadmap_id and r.user_id=auth.uid()));
create policy phase2_tasks_write_own on public.phase2_roadmap_tasks for all using (exists(select 1 from public.phase2_roadmaps r where r.id=roadmap_id and r.user_id=auth.uid())) with check (exists(select 1 from public.phase2_roadmaps r where r.id=roadmap_id and r.user_id=auth.uid()));
alter table public.phase2_messages enable row level security;
create policy phase2_messages_read_own on public.phase2_messages for select using (exists(select 1 from public.phase2_conversations c where c.id=conversation_id and c.user_id=auth.uid()));
create policy phase2_messages_write_own on public.phase2_messages for insert with check (exists(select 1 from public.phase2_conversations c where c.id=conversation_id and c.user_id=auth.uid()));
alter table public.phase2_opportunities enable row level security;
create policy phase2_opportunities_published_read on public.phase2_opportunities for select using (published = true);
alter table public.phase2_resources enable row level security;
create policy phase2_resources_published_read on public.phase2_resources for select using (published = true);
-- Never expose answer keys in client-readable tables; score in a trusted server function.
