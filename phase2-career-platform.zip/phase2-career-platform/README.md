# College Companion — Phase 2 (standalone integration package)

A separately runnable Phase 2 implementation package covering careers, opportunities, roadmaps, learning resources, assessments, mock interviews, and an AI study companion. **The Phase 1 source repository was not present when this package was built**, so this is not a merged Phase 1 branch. Treat it as a working reference implementation and adapt the included integration guide/migration into the Phase 1 app once the other agent's code is available.

## What is implemented

- **Opportunity portal:** server-side search and kind filters; opportunity detail; bookmark and application tracker; duplicate applications rejected by a database unique constraint; statuses can be updated.
- **Career discovery:** editable interest, learning-style, time and skill responses persisted for the signed-in demo profile; transparent rule-of-thumb recommendations; path comparison.
- **Roadmaps:** create a domain-specific starter plan; SQLite persistence for plans and tasks; toggle task completion; progress calculated from persisted tasks.
- **Resource library:** curated provider/documentation links; search, difficulty filter and persistent bookmarks.
- **Assessments:** objective question set delivered without answer keys; server-side scoring and persistent attempt history; result review and explanations.
- **Mock interviews:** text-based sessions persisted with answers and feedback; supports continued practice and history.
- **AI companion:** persistent conversations/messages, validation and per-user short-term request limiting; optional server-side OpenAI-compatible provider, bounded output and timeout; honest fallback when no key is configured.
- Responsive layouts for narrow and wide screens, keyboard focus styling, useful empty/error states, and seeded demonstration data.

## Local setup

Requirements: Node.js 20+ and npm; native build tools may be needed by `better-sqlite3` on your platform.

```bash
cp .env.example .env
npm install
npm run dev
```

Open <http://localhost:5173>. In local development the UI automatically invokes a **demo-only** sign-in for the seeded student Alex Morgan. API runs on port 8787 and SQLite data lives in `server/phase2.sqlite`. Set `DB_FILE` to move the local database. The demo login is deliberately disabled when `NODE_ENV=production`; the HMAC session secret must be changed for any non-demo deployment.

### AI provider (optional)

Set `OPENAI_API_KEY` in the server environment. Optional `OPENAI_API_BASE` and `OPENAI_MODEL` control an OpenAI-compatible chat completion provider. The key is only read by the API server; never prefix it with `VITE_`. If the key is absent the companion explains the limited fallback instead of simulating an AI response. No assessment or interview AI grading is claimed: interview feedback currently uses a simple static coaching rubric, clearly presented as reflective advice.

### Build and checks

```bash
npm run build
npm test
```

API health check: `GET http://localhost:8787/api/health`. `npm run start` runs the API plus Vite preview, which is suitable for local review, **not a production hosting recipe**. For production, serve the compiled `dist/` through an HTTPS web server and configure a separately deployed API, secure cookies, proper origin/CORS rules, production database, monitoring and an existing identity provider.

## Phase 1 integration guide

1. Inspect Phase 1 routes, auth/session, profile IDs and roles, notification model, UI tokens, current database and deployment config. No Phase 1 files are modified by this bundle.
2. Port the screens in `src/main.tsx` into Phase 1 routes/components, replacing the local shell and sample college/user identity with existing navigation, profile and dashboard primitives. Keep design tokens consistent with the Phase 1 design system.
3. Replace demo HMAC login in `server/index.js` with Phase 1 Supabase Auth/session middleware. Derive user identity only from the verified server session; never accept a user ID from a client body or header. The current demo user is only for a local demo.
4. Use the SQL in `supabase/migrations/202610100001_phase2_foundation.sql` as an integration starting point. Reconcile every foreign key to the Phase 1 profile/auth schema first; the included SQLite server schema is intentionally independent.
5. Route new notifications through the existing Phase 1 notification system; configure a scheduler before promising reminders. Connect actual permitted job feeds/imports and store provenance. Demo job rows and curated resource rows are sample records, not verified live opportunities.
6. Map access rules and tests to the college's student/faculty/admin roles. Do not give staff access to private chat/interview content by default.

## Schema & data notes

The standalone backend creates its own SQLite tables on startup: users, opportunities, saved opportunities, applications, career profiles, roadmaps/tasks, resource bookmarks, assessment attempts, interviews, conversations and messages. Foreign keys, user ownership filtering and unique constraints are applied for the demo workflows. The separate Supabase SQL file is a **starting migration sketch** for integration, not executed/tested against the absent Phase 1 schema. Do not run it unchanged until IDs and role model are reconciled.

## Honest limitations before production

- Not merged with Phase 1; no Phase 1 source was supplied to inspect or regression-test.
- Standalone demo auth is intentionally development-only. No production login, role management, Supabase Auth, PostgreSQL RLS, administrator workflow, SSO, or notification delivery is included.
- Local seeded opportunity listings are expressly demo examples with example.com links; they are not real/verified employment listings. No CSV import or job provider is connected.
- Resource links are curated starting points; availability has not been programmatically checked.
- The career recommendation is a transparent heuristic based on selections, not an AI fit score. Recommendation history/versioning and three-way detailed comparisons are not persisted.
- Roadmap task structure is a starter template rather than provider-backed AI generation; roadmap edit/pause/regenerate and milestone dependencies are not implemented.
- Assessments support objective MCQ only. The question bank is demo seed data; admin authoring, timed attempts and detailed skill analytics are not present.
- Mock interview feedback is deterministic coaching text, not AI evaluation; voice input/output and rubric scores are not implemented.
- Companion context-sharing switch is informational/off by default; profile context is not sent. Conversation view/list navigation and deletion controls are not exposed in the UI.
- No production-grade CSRF strategy, account lifecycle, privacy export/deletion flow, audit trail, email reminders, comprehensive automated tests, full accessibility audit, or deployment platform config has been validated.

## Production checklist

Integrate Phase 1 auth and existing user records; migrate to the existing PostgreSQL/Supabase schema with RLS; configure HTTPS/secure session cookies and allowed origins; replace demo opportunities with provenance-backed approved feeds; add admin authorization and audit logs; set AI provider policy, spend limits, rate-limit storage and moderation; configure retention/deletion and notification scheduler; add unit/integration/E2E and role-isolation tests; run migration against a clean staging database; then build and deploy using the existing platform.
