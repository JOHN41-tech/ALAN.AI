import {describe,it,expect} from 'vitest';
const score=(answers:Record<string,number>,key:Record<string,number>)=>Object.entries(key).reduce((n,[id,value])=>n+(answers[id]===value?1:0),0);
describe('objective assessment scoring',()=>{const key={q1:1,q2:1,q3:2};it('scores correct answers',()=>expect(score({q1:1,q2:1,q3:2},key)).toBe(3));it('does not award marks for incorrect or omitted answers',()=>expect(score({q1:0,q2:1},key)).toBe(1));it('does not accept string answer indexes as correct',()=>expect(score({q1:'1' as unknown as number},key)).toBe(0))});
